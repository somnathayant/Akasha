package com.ayatsoft.tms.model;

public class TaskGroup {
	String id;
	String name;
	String assigne;
	String depertment;
	
	
	
	public TaskGroup() {
		super();
	}
	public TaskGroup(String id, String name, String assigne, String depertment) {
		super();
		this.id = id;
		this.name = name;
		this.assigne = assigne;
		this.depertment = depertment;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAssigne() {
		return assigne;
	}
	public void setAssigne(String assigne) {
		this.assigne = assigne;
	}
	public String getDepertment() {
		return depertment;
	}
	public void setDepertment(String depertment) {
		this.depertment = depertment;
	}

	
	

}

package com.ayantsoft.tms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ayantsoft.tms.dao.UserDao;
import com.ayatsoft.tms.dto.LoginInfo;
import com.ayatsoft.tms.model.User;
@Service
public class UserServiceImpl implements UserService {
   
	@Autowired
	UserDao userDao;
	
	@Override
	public List<User> listUser() {
		return userDao.listUser();
	}

	@Override
	public void addUser(LoginInfo user) {
		userDao.addUser(user);
		
	}

	@Override
	public void updateUser(User user) {
		userDao.updateUser(user);
		
	}

	@Override
	public void delete(User user) {
		userDao.delete(user);
		
	}

	@Override
	public User findUserById(String id) {
		return userDao.findUserById(id);
	}

}

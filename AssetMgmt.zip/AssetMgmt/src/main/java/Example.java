 
class Address{
	
public void display(){
		
		System.out.println("we are in class Address");
	}
public void display1(){
	
	System.out.println("we are in class Address");
}
}



class Student extends Address{
	
	private String studentName;
	
	public void display(){
		super.display();//called address class
		System.out.println("we are in class Student");
	}
public void display(int i){
		
		System.out.println("method overloading");
	}
}


public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("ok");
		Student ob=new Student();
		//ob.display();//this one
		ob.display();
	}

}

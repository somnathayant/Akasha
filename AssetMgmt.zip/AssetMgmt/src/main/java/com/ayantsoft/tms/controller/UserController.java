package com.ayantsoft.tms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.tms.service.UserService;
import com.ayatsoft.tms.dto.LoginInfo;
import com.ayatsoft.tms.dto.Response;
import com.ayatsoft.tms.model.User;

@RestController
public class UserController{

	@Autowired
	UserService userService;
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getCandidateMsts(){
		System.out.println("getUser");
		ModelAndView mv=new ModelAndView();
		mv.setViewName("welcome");
		return mv;
	}
	
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public ResponseEntity<?> addUser(@RequestBody LoginInfo user){
		System.out.println("addUser");
          HttpStatus httpStatus = null;
          Response res=new Response();
		try{
			System.out.println(user.getPassword());
			System.out.println(user.getUserId());
			userService.addUser(user);
			res.setRe("ok");
		    httpStatus = HttpStatus.CREATED;
		}catch(Exception e){
			httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Response>(res, httpStatus);
	}

}

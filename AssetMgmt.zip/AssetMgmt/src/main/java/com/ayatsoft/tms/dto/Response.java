package com.ayatsoft.tms.dto;

public class Response {
	private String re;

	//getter and setter
	public String getRe() {
		return re;
	}

	public void setRe(String re) {
		this.re = re;
	}
	

	
}

package com.ayantsoft.tms.dao;

import java.util.List;

import com.ayatsoft.tms.dto.LoginInfo;
import com.ayatsoft.tms.model.User;

public interface UserDao {
   
	public List<User>listUser();
	public void addUser(LoginInfo user);
	public void updateUser(User user);
	public void delete(User user);
	public User findUserById(String id);
}
